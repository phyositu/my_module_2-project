from django.db import models
from django.utils import timezone
from hr_jobs.models import JobModel
from hr_tags.models import EmployeeTagModel

# Create your models here.
class EmployeeModel(models.Model):
    def __str__(self):
        return self.name
    class Meta:
        permissions = (
            ('view_employeemodel', 'Can view employee model'),
        )
    name = models.CharField(max_length = 200, verbose_name = "Name")
    age = models.IntegerField(verbose_name = "Age")
    birthday = models.DateField(verbose_name = "Birthday", default=timezone.now)
    address = models.TextField(verbose_name = "address")
    email = models.EmailField(max_length = 100, verbose_name = "Email", default = "test@gmail.com")
    gender = models.TextField(max_length = 20, verbose_name = "Gender", default = "Other")
    is_married = models.BooleanField(verbose_name = "Is Married?", default = False)
    joining_date = models.DateTimeField(verbose_name = "Joining Date", default = timezone.now)
    image = models.ImageField(verbose_name = "Profile Image", default = None)
    job = models.ForeignKey(JobModel, on_delete = models.CASCADE, default = None)
    tags = models.ManyToManyField(EmployeeTagModel)