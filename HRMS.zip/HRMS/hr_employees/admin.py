from django.contrib import admin
from .models import EmployeeModel
class EmployeeModelAdmin(admin.ModelAdmin):
    list_display = ["name", "age", "birthday", "address", "email"]

admin.site.register(EmployeeModel, EmployeeModelAdmin)

