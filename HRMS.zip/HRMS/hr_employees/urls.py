from django.urls import path
from .import views
urlpatterns = [
    path('show_employees/', views.all_employees),
    path('new_employee/', views.new_employee),
    path('update/<int:employee_id>/', views.update_employee),
    path('detail/<int:employee_id>/', views.employee_detail),
    path('delete/<int:employee_id>/', views.delete),
    path('order_by/', views.order_by),
    path('search_by/', views.search_by),
]