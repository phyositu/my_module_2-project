from django.shortcuts import render, redirect
from .models import EmployeeModel
from datetime import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import Q
from hr_jobs.models import JobModel
from hr_tags.models import EmployeeTagModel
from django.core.paginator import Paginator
from django.contrib import messages

def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username = username, password = password)
        if user is not None:
            login(request, user)
            messages.success(request,f"Hello {username}.Welcome!")

            return redirect("/hr_employees/show_employees")
        else:
            messages.error(request, "Username or password is wrong!")
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')
    
def permisssion_required_view(request):
    return render(request, "permission_required.html")
    
def logout_view(request):
    logout(request)
    messages.success(request, "logout successfully")
    return redirect('/login/')

def order_by(request):
    order = request.GET.get('order')
    employees = EmployeeModel.objects.all().order_by("-"+ order).reverse()
    paginator = Paginator(employees,2)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    order_selected = { order: 'btn btn-primary text-white'}
    context = {"page_obj": page_obj, "order_selected": order_selected}
    return render(request, 'employee_list.html', context)

def search_by(request):
    print("search_by function call")
    search = request.GET.get('search')
    if search:
        employees = EmployeeModel.objects.filter(
            Q(name__icontains = search)|
            Q(age__icontains = search)|
            Q(address__icontains = search)|
            Q(birthday__icontains = search)|
            Q(email__icontains = search)|
            Q(gender__icontains = search)|
            Q(joining_date__icontains = search)
            )
        print(type(employees))
    else:
        employees = EmployeeModel.objects.all()
    return render(request, 'employee_list.html', {'page_obj': employees})

@login_required(login_url='login')   
def all_employees(request):
    employee = request.GET.get("type")
    employees = EmployeeModel.objects.all()
    paginator = Paginator(employees,2)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    employee_page = {employee: "bg-white text-dark rounded-pill"}
    return render(request, 'employee_list.html', {'page_obj': page_obj,"active": employee_page})
 
@permission_required('hr_employees.add_employeemodel', login_url="permission_required")
def new_employee(request):
    
    if request.method == "GET":
        jobs = JobModel.objects.all()
        tags = EmployeeTagModel.objects.all()
        context = {
            'all_jobs': jobs,
            'all_tags': tags
            }
        return render(request, 'employee_create.html', context)
    if request.method == "POST" and request.FILES['image']:
        name = request.POST.get('name')
        age = request.POST.get('age')
        birthday = request.POST.get('birthday')
        address = request.POST.get('address')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        if request.POST.get('is_married') == "on":
            is_married = True
        else:
            is_married = False
        joining_date = request.POST.get('joining_date')
        image = request.FILES.get('image')
        job = request.POST.get('job')
        tags = request.POST.get('tag')
        employee = EmployeeModel.objects.create(
            name = name,
            age = age,
            birthday = birthday,
            address = address,
            email = email, 
            gender = gender,
            is_married = is_married,
            joining_date = joining_date,
            image = image,
            job_id = job,
        )
        employee.tags.set(tags)
        employee.save()
        messages.success(request, "A employee created successfully")
        return redirect('/hr_employees/show_employees/')
    
@permission_required('hr_employees.change_employeemodel', login_url="permission_required")  
def update_employee(request, employee_id):
    employee = EmployeeModel.objects.get(id = employee_id)
    
    if request.method == "GET":
        jobs = JobModel.objects.all()
        tags = EmployeeTagModel.objects.all()
        employee.birthday = str(employee.birthday)
        employee.joining_date = datetime.strftime(employee.joining_date, '%Y-%m-%dT%H:%M' )
        context = {
            'employee': employee,
            'uploaded_image': employee.image,
            'jobs': jobs,
            'tags': tags
        }
        return render(request, 'employee_update.html', context)
    
    elif request.method == "POST":
        employee.name = request.POST.get('name')
        employee.age = request.POST.get('age')
        employee.birthday = request.POST.get('birthday')
        employee.address = request.POST.get('address')
        employee.email = request.POST.get('email')
        employee.gender = request.POST.get('gender')
        if request.POST.get('is_married') == 'on':
            employee.is_married = True
        else:
            employee.is_married = False
        employee.joining_date = request.POST.get('joining_date')
        if request.FILES.get('image'):
            employee.image = request.FILES.get("image")
        employee.job_id = request.POST.get("job")
        employee.tags.set(request.POST.getlist("tags"))
        employee.save()
        messages.success(request, "A employee updated successfully")
        return redirect('/hr_employees/detail/' + str(employee_id) + '/')
    
@permission_required('hr_employees.view_employeemodel', login_url="permission_required")
def employee_detail(request, employee_id):
    if request.method == "GET":
        employee = EmployeeModel.objects.get(id = employee_id)
        employee.birthday = str(employee.birthday)
        employee.joining_date = employee.joining_date.strftime('%Y-%m-%dT%H:%M')
        return render(request, "employee_detail.html", {'employee': employee})
    
@permission_required('hr_employees.delete_employeemodel', login_url = 'permission_required')
def delete(request, employee_id):
    if request.method == "GET":
        employee = EmployeeModel.objects.get(id = employee_id)
        employee.delete()
        messages.error(request, "A employee deleted successfully")
        return redirect("/hr_employees/show_employees/")
