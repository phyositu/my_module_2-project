from django.db import models
from hr_employees.models import EmployeeModel
from hr_departments.models import DepartmentModel
from django.utils import timezone
class ExpenseModel(models.Model):
    def __str__(self):
        return self.employee.name
    class Meta:
        permissions = (
            ("view_expensemodel", "can view expense model"),
        )
    employee = models.ForeignKey(EmployeeModel, on_delete=models.CASCADE, verbose_name = "Employee", default = None)
    department = models.ForeignKey(DepartmentModel, on_delete = models.CASCADE, verbose_name = "Department", default = None)
    expense_category = models.CharField(verbose_name = "Expense Catergory", max_length = 50)
    expense_amount = models.DecimalField(verbose_name = "Expense Amount", max_digits=10, decimal_places=2)
    expense_date = models.DateField(verbose_name = "Expense Date", default = timezone.now)
    description = models.TextField(verbose_name = "Description", null = True, blank = True)
    is_approved = models.BooleanField(verbose_name = "Is Approve?", default = False)
    approval_date = models.DateField(verbose_name = "Approval Date", default = timezone.now)
    payment_date = models.DateField(verbose_name = "Payment Date")