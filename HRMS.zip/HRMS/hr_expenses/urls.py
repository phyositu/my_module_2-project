from django.urls import path

from hr_expenses import views

urlpatterns = [
    path("show_expenses/", views.ExpenseListView.as_view(),name = "expense_list"),
    path("new_expense/", views.ExpenseCreateView.as_view(),name = "expense_create"),
    path("detail/<int:pk>/", views.ExpenseDetailView.as_view(),name = "expense_detail"),
    path("update/<int:pk>/", views.ExpenseUpdateView.as_view(),name = "expense_update"),
    path("delete/<int:pk>/", views.ExpenseDeleteView.as_view(),name = "expense_delete"),
    path("search_by/", views.SearchBy.as_view(),)

]