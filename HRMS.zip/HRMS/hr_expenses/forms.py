from django import forms
from django.forms import widgets
from .models import ExpenseModel
CATEGORY_CHOICES = (
    ("transportation","Transportation"),
    ("utilities","Utilities"),
    ("food","Food"),
    ("healthcare","Healthcare"),
    ("education","Education"),
)
class ExpenseForm(forms.ModelForm):
    class Meta:
        model = ExpenseModel
        fields = "__all__"
        labels = {
            "employee": "Employee",
            "department": "Department",
            "expense_category": "Expense Category",
            "expense_amount": "Expense Amount",
            "expense_date": "Expense Date",
            "description": "Description",
            "is_approved": "Is Approved",
            "approval_date": "Approved Date",
            "payment_date": "Payment Date"
        }
        widgets = {
            "employee": widgets.Select(attrs={"class": "form-control"}),
            "department": widgets.Select(attrs={"class": "form-control"}),
            "expense_category": widgets.Select(choices=CATEGORY_CHOICES, attrs={"class": "form-control"}),
            "expense_amount": widgets.NumberInput(attrs={"placeholder": "Enter Expense Amount", "class": "form-control"}),
            "expense_date": widgets.DateInput(attrs={"type": "date", "class": "form-control"}),
            "description": widgets.Textarea(attrs={"placeholder": "Description", "class": "form-control"}),
            "is_approved": widgets.CheckboxInput(),
            "approval_date": widgets.DateInput(attrs={"type": "date", "class": "form-control"}),
            "payment_date": widgets.DateInput(attrs={"type": "date", "class": "form-control"})
        }
