from django.shortcuts import render, redirect
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, UpdateView,DetailView,DeleteView, View
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from .models import ExpenseModel
from .forms import ExpenseForm
from django.db.models import Q
from django.contrib import messages

class SearchBy(View):
    def get(self, request):
        search = request.GET.get("search")
        if search:
            expense = ExpenseModel.objects.filter(
                Q(employee__name__icontains = search)|
                Q(department__name__icontains = search)|
                Q(expense_date__icontains = search)|
                Q(expense_amount__icontains = search)
                )
        else:
            expense = ExpenseModel.objects.all()
        return render(request, "expense_list.html", {"all_expenses": expense})

class ExpenseListView(LoginRequiredMixin, ListView):
    paginate_by  = 2
    login_url = "login"
    model = ExpenseModel
    template_name = "expense_list.html"
    context_object_name = "all_expenses"
    def get_queryset(self):
        qs = super().get_queryset()
        order = self.request.GET.get("order")
        if order is not None:
            qs = ExpenseModel.objects.all().order_by("-" + order)
        return qs

class ExpenseCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    login_url = "permission_required"
    permission_required = "hr_expenses.add_expensemodel"
    model = ExpenseModel
    form_class = ExpenseForm
    context_object_name = "form"
    template_name = "expense_create.html"
    success_url = reverse_lazy("expense_list")
    def form_valid(self, form):
        messages.success(self.request, 'An Expense created successfully!')
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, 'something wrong. try again!')
        return super().form_invalid(form)

class ExpenseDetailView(LoginRequiredMixin, PermissionRequiredMixin,  DetailView):
    login_url = "permission_required"
    permission_required = "hr_expenses.view_expensemodel"
    model = ExpenseModel
    context_object_name = "expense"
    template_name = "expense_detail.html"

class ExpenseUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    login_url = "permission_required"
    permission_required = "hr_expenses.update_expensemodel"
    model = ExpenseModel
    form_class = ExpenseForm
    context_object_name = "form"
    template_name = "expense_update.html"
    success_url = reverse_lazy("expense_list")
    def form_valid(self, form):
        messages.success(self.request, 'An Expense updated successfully!')
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, 'something wrong. try again!')
        return super().form_invalid(form)

class ExpenseDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    login_url = "permission_required"
    permission_required = "hr_expenses.delete_expensemodel"
    model = ExpenseModel
    context_object_name = "expense"
    template_name = "expense_delete.html"
    success_url = reverse_lazy("expense_list")

    def delete(self, request, *args, **kwargs):
        try:
            messages.error(self.request, 'An expense deleted successfully.')
            return super().delete(request, *args, **kwargs)

        except Exception as e:
            messages.error(self.request, f'Error deleting item: {str(e)}')
            return redirect(self.success_url)
    