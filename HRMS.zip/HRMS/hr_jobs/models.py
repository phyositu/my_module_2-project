from django.db import models
from django.utils import timezone
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel
class JobModel(models.Model):

    def __str__(self):
        return self.name 
    class Meta:
        permissions = (
            ('view_jobmodel', 'Can view job model'),
        )
    name = models.CharField(max_length = 20, verbose_name = "Name",)
    sequence = models.IntegerField(verbose_name = "Sequence")
    open_date = models.DateField(verbose_name = "Open Date", default=timezone.now)
    expected_salary = models.CharField(max_length = 20, verbose_name = "Expected Salary",)
    note = models.TextField(max_length = 100, verbose_name = "Note")
    status = models.CharField(max_length = 20, verbose_name = "Status")
    is_active = models.BooleanField(verbose_name = "is Active", default= False)
    create_date = models.DateTimeField(verbose_name = "Create Date", default = timezone.now)
    attachment = models.ImageField(verbose_name = "Attachment", default = None)
    department = models.ForeignKey(DepartmentModel, on_delete = models.CASCADE, default = None)
    tags = models.ManyToManyField(JobTagModel)
