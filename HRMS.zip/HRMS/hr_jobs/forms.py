from django import forms
from django.forms import widgets
from .models import JobModel
STATUS_CHOICES = (
    ('draft', 'Draft'),
    ('open', 'Open'),
    ('confirm', 'Confirm')
)
class JobForm(forms.ModelForm):
    class Meta:
        model = JobModel
        fields = "__all__"
        labels = {
            'name': "Job Name", 
            'sequence': "Sequence",
            'open_date': "Open Date",
            'expected_salary': "Expected Salary",
            'note': "Note",
            'status': "Status",
            'is_active': "Is Active",
            'create_date': "Create Date",
            'attachment': "Attachment",
            'department': 'Department',
            'tags': 'Tags'
        }
        widgets = {
            'name': widgets.TextInput(attrs={'placeholder': "Enter Job Name", "class": 'form-control'}),
            'sequence': widgets.NumberInput(attrs = {'placeholder': "Enter Sequence", "class": 'form-control'}),
            'open_date': widgets.DateInput(attrs = {'type': 'date', "class": 'form-control'}),
            'expected_salary': widgets.TextInput(attrs = {'placeholder': "Enter Expected Salary", "class": 'form-control'}),
            'note': widgets.TextInput(attrs = {'placeholder': 'Note', "class": 'form-control'}),
            'status': widgets.Select(choices=STATUS_CHOICES, attrs={'class': 'form-control'}),
            'is_active': widgets.CheckboxInput(),
            'create_date': widgets.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'attachment': widgets.ClearableFileInput(),
            'department': widgets.Select(attrs = {'class': 'form-control'}),
            'tags': widgets.CheckboxSelectMultiple()
        }