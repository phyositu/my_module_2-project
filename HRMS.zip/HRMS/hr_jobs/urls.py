from django.urls import path
from hr_jobs import views
urlpatterns = [
    path('show_jobs/',views.all_jobs),
    path('new_job/', views.new_job),
    path('update/<int:job_id>/', views.update_job),
    path('detail/<int:job_id>/', views.detail_job),
    path('delete/<int:job_id>/', views.delete_job),
    path('order_by/', views.order_by),
    path('search_by/', views.search_by),
]