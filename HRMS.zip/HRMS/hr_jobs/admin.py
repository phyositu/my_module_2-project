from django.contrib import admin
from .models import JobModel

admin.site.register(JobModel)
