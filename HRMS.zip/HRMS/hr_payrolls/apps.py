from django.apps import AppConfig


class HrPayrollsConfig(AppConfig):
    name = 'hr_payrolls'
