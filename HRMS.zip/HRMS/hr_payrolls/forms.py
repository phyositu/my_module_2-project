from django import forms
from django.forms import widgets
from hr_employees.models import EmployeeModel

PAYMENT_CHOICES = (
    ("cash", "Cash"),
    ("bank transfers", "Bank Transfers"),
    ("credit and debit cards", "Credit and Debit Cards"),
    ("mobile wallets", "Mobile Wallets"),
    ("online banking", "Online Banking")

)
class PayRollForm(forms.Form):
    employee = forms.ModelChoiceField(queryset = EmployeeModel.objects.all(), widget = widgets.Select(attrs = {"class": 'form-control'}))
    salary = forms.DecimalField(label = "Salary", widget = widgets.NumberInput(attrs = {"placeholder": "Enter Salary", "class": "form-control"}))
    payment_date = forms.DateField(label = "Payment Date", widget = widgets.DateInput(attrs = {'type': "date", "class": "form-control"}))
    deductions = forms.DecimalField(label = "Deductions", widget = widgets.NumberInput(attrs = {"placeholder": "Enter Deduction", "class": 'form-control'}), required = False)
    bonuses = forms.DecimalField(label = "Bonuses", widget = widgets.NumberInput(attrs = {"placeholder": "Enter Bonuses", "class": "form-control"}), required = False)
    net_pay = forms.DecimalField(label = "Net pay", widget = widgets.NumberInput(attrs = {"class": "form-control", "readonly": True}))
    payment_method = forms.ChoiceField(label = "Payment Method", choices= PAYMENT_CHOICES, widget = widgets.Select(attrs = {"class": "form-control"}))
    transaction_id = forms.CharField(label = "Transaction Id", widget = widgets.TextInput(attrs = {"class": "form-control", "readonly": True}))
    note = forms.CharField(label = "Note", widget = widgets.TextInput(attrs = {"placeholder": "Enter Note", "class": "form-control"}),required=False)                               