from django.db import models

from hr_employees.models import EmployeeModel

class PayRollModel(models.Model):
    def __str__(self):
        return self.employee.name
    
    class Meta:
        permissions = (
            ("view_payrollmodel", "can view payrollmodel"),
        )
    
    employee = models.ForeignKey(EmployeeModel, on_delete=models.CASCADE, verbose_name = "Employee", default = None)
    salary = models.DecimalField(verbose_name="Salary", decimal_places=2, max_digits=10)
    payment_date = models.DateField(verbose_name = "Payment Date")
    deductions = models.DecimalField(verbose_name = "Deductions", max_digits=10, decimal_places=2, default = "0.0")
    bonuses = models.DecimalField(verbose_name = "Bonuses", decimal_places=2, max_digits=10, default = "0.0")
    net_pay = models.DecimalField(verbose_name="Net Pay", max_digits=10, decimal_places=2)
    payment_method = models.CharField(verbose_name = "Payment Method", max_length=100)
    transaction_id = models.CharField(verbose_name = "Transaction Id", max_length = 4)
    note = models.TextField(verbose_name = "Note", null = True, blank = True)
