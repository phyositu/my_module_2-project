from django.contrib import admin
from .models import PayRollModel
admin.site.register(PayRollModel)