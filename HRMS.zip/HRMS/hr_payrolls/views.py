from django.shortcuts import render, redirect
from django.views import View
from .models import PayRollModel
from .forms import PayRollForm
from django.db.models import Q
from django.core.paginator import Paginator
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
import random
from django.contrib import messages

class OrderBy(View):
    def get(self, request):
        page_num = request.GET.get("page")
        order = request.GET.get("order")
        payroll = PayRollModel.objects.all().order_by("-" + order).reverse()
        panginator = Paginator(payroll, 2)
        page_obj = panginator.get_page(page_num)
        order_selected = {order: "btn btn-primary text-white"}
        return render(request, "payroll_list.html", {"page_obj": page_obj, "order_selected": order_selected})

class SearchBy(View):
    def get(self, request):
        search = request.GET.get("search")
        if search:
            payroll = PayRollModel.objects.filter(
                Q(employee__name__icontains = search)|
                Q(salary__icontains = search)|
                Q(payment_date__icontains = search)|
                Q(deductions__icontains = search)|
                Q(net_pay__icontains = search)
                )
        else:
            payroll = PayRollModel.objects.all()
        return render(request, "payroll_list.html", {"page_obj": payroll})

class AllPayroll(LoginRequiredMixin, View):
    login_url = "login"
    def get(self, request):
        page_num = request.GET.get("page")
        payroll = request.GET.get("type")
        payrolls = PayRollModel.objects.all()
        paginator = Paginator(payrolls, 2)
        page_obj = paginator.get_page(page_num)
        active = {payroll: "bg-white text-dark rounded-pill"}
        return render(request, "payroll_list.html",{"page_obj": page_obj, "active": active})
    
class NewPayRoll(LoginRequiredMixin,PermissionRequiredMixin,View):
    login_url = "permission_required"
    permission_required = "hr_payrolls.add_payrollmodel"
    
    def get(self, request):
        random_id = random.randint(1000,9999)
        values = {
            "transaction_id": random_id,
            }
        form = PayRollForm(initial=values)

        return render(request, "payroll_create.html", {"form": form})
    
    def post(self, request):
        form = PayRollForm(request.POST)
        if form.is_valid():
            employee = form.cleaned_data.get("employee")
            salary = form.cleaned_data.get("salary")
            payment_date = form.cleaned_data.get("payment_date")
            deductions = form.cleaned_data.get("deductions")
            bonuses = form.cleaned_data.get("bonuses")
            net_pay = form.cleaned_data.get("net_pay")
            payment_method = form.cleaned_data.get("payment_method")
            transaction_id = form.cleaned_data.get("transaction_id")
            note = form.cleaned_data.get("note")
            payroll = PayRollModel.objects.create(
                employee = employee,
                salary = salary,
                payment_date = payment_date,
                deductions = deductions,
                bonuses = bonuses,
                net_pay = net_pay,
                payment_method = payment_method,
                transaction_id = transaction_id,
                note = note
            )
            payroll.save()
            messages.success(request, "A payroll created successfully")
            return redirect("/hr_payrolls/show_payrolls/")
        
class PayRoll(LoginRequiredMixin,PermissionRequiredMixin, View):
    login_url = "permission_required"
    permission_required = "hr_payrolls.view_payrollmodel"

    def get(self, request, payroll_id):
        payroll = PayRollModel.objects.get(id=payroll_id)
        payroll.payment_date = str(payroll.payment_date)
        return render(request, "payroll_detail.html", {"payroll": payroll})

class UpdatePayRoll(LoginRequiredMixin,PermissionRequiredMixin, View):
    login_url = "permission_required"
    permission_required = "hr_payrolls.update_payrollmodel"

    def get(self, request, payroll_id):
        payroll = PayRollModel.objects.get(id = payroll_id)
        values = {
            "employee": payroll.employee,
            "salary": payroll.salary,
            "payment_date": payroll.payment_date,
            "deductions": payroll.deductions,
            "bonuses": payroll.bonuses,
            "net_pay": payroll.net_pay,
            "payment_method": payroll.payment_method,
            "transaction_id": payroll.transaction_id,
            "note": payroll.note
        }
        print(payroll)
        form = PayRollForm(initial=values)
        return render(request, "payroll_update.html", {"form": form, "payroll": payroll})
    
    def post(self, request, payroll_id):
        payroll = PayRollModel.objects.get(id = payroll_id)
        form = PayRollForm(request.POST)
        if form.is_valid():
            payroll.employee = form.cleaned_data.get("employee")
            payroll.salary = form.cleaned_data.get("salary")
            payroll.payment_date = form.cleaned_data.get("payment_date")
            payroll.deductions = form.cleaned_data.get("deductions")
            payroll.bonuses = form.cleaned_data.get("bonuses")
            payroll.net_pay = form.cleaned_data.get("net_pay")
            payroll.payment_method = form.cleaned_data.get("payment_method")
            payroll.note = form.cleaned_data.get('note')
            payroll.save()
            messages.success(request, "A payroll updated successfully")
            return redirect("/hr_payrolls/detail/" + str(payroll_id) + "/")

class DeletePayRoll(LoginRequiredMixin, PermissionRequiredMixin, View):
    login_url = "permission_required"
    permission_required = "hr_payrolls.delete_payrollmodel"

    def get(self, request, payroll_id):
        payroll = PayRollModel.objects.get(id = payroll_id)
        payroll.delete()
        messages.error(request, "A payroll deleted successfully")
        return redirect("/hr_payrolls/show_payrolls")



