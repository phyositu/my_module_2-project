from django.urls import path
from hr_payrolls import views

urlpatterns = [
    path("show_payrolls/", views.AllPayroll.as_view()),
    path("new_payroll/", views.NewPayRoll.as_view()),
    path("detail/<int:payroll_id>/", views.PayRoll.as_view()),
    path("update/<int:payroll_id>/", views.UpdatePayRoll.as_view()),
    path("delete/<int:payroll_id>/", views.DeletePayRoll.as_view()),
    path("order_by/", views.OrderBy.as_view()),
    path("search_by/", views.SearchBy.as_view())
]