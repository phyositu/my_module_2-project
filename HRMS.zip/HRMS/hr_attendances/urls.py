from django.urls import path
from hr_attendances import views

urlpatterns = [
    path("show_attendances/", views.all_attendances),
    path("new_attendance/", views.attendance_create),
    path("detail/<int:attend_id>/", views.attendance_detail),
    path("update/<int:attend_id>/", views.attendance_update),
    path("delete/<int:attend_id>/", views.attendance_delete),
    path("order_by/", views.order_by),
    path("search_by/", views.search_by)
]