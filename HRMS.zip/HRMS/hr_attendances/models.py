from django.db import models
from hr_employees.models import EmployeeModel
from django.utils import timezone

class AttendanceModel(models.Model):
    def __str__(self):
        return self.employee.name
    class Meta:
        permissions = (
            ('view_attendance', "Can view attendance model"),
        )
    employee = models.ForeignKey(EmployeeModel,verbose_name = "Employee", on_delete=models.CASCADE, default=None)
    date = models.DateField(verbose_name = "Date", default=timezone.now)
    check_in = models.TimeField(verbose_name = "Check in")
    check_out = models.TimeField(verbose_name = "Check out")
    is_present = models.BooleanField(verbose_name = "Is present", default = False)
    overtime_hours = models.DecimalField(verbose_name = "Overtime hours", max_digits=5, decimal_places=2, default=0.0)
    leave_type = models.CharField(verbose_name = "Leave Type", max_length=20, null=True, blank=True)
    leave_reason = models.TextField(verbose_name="Leave Reason", null=True, blank=True)
    notes = models.TextField(verbose_name = "Note", null=True, blank=True)