from django.apps import AppConfig


class HrAttendancesConfig(AppConfig):
    name = 'hr_attendances'
