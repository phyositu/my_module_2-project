from django.shortcuts import render, redirect

from .models import AttendanceModel
from hr_employees.models import EmployeeModel
from django.core.paginator import Paginator
from django.db.models import Q
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib import messages
def search_by(request):
    search = request.GET.get('search')
    if search:
        attendances = AttendanceModel.objects.filter(
            Q(employee__name__icontains = search)|
            Q(date__icontains = search)|
            Q(check_in__icontains = search)|
            Q(check_out__icontains = search)|
            Q(is_present__icontains = search)|
            Q(leave_reason__icontains = search)|
            Q(notes__icontains = search)
            )
    else:
        attendances = AttendanceModel.objects.all()
    return render(request, 'attendance_list.html', {'page_obj': attendances})

def order_by(request):
    page_num = request.GET.get("page")
    order = request.GET.get("order")

    attendance = AttendanceModel.objects.all().order_by("-"+ order).reverse()
    paginator = Paginator(attendance, 2)
    page_obj = paginator.get_page(page_num)
    order_selected = {order: "btn btn-primary text-white"}
    return render(request, "attendance_list.html", {"page_obj": page_obj, "order_selected": order_selected})

@login_required(login_url="login")
def all_attendances(request):
    attendance = request.GET.get('type')
    attendance_page = {attendance: "bg-white text-dark rounded-pill"}
    attendances = AttendanceModel.objects.all()
    paginator = Paginator(attendances, 2)
    page_number = request.GET.get("page")
    page_obj = paginator.get_page(page_number)
    return render( request, "attendance_list.html", {"page_obj": page_obj, "active": attendance_page})

@permission_required("hr_attendances.add_attendancemodel", login_url = "permission_required")
def attendance_create(request):
    
    if request.method == "GET":
        employees = EmployeeModel.objects.all()
        return render(request, "attendance_create.html", {"all_employees": employees})
    if request.method == "POST":
        print(request.POST)
        employee = request.POST.get("employee")
        date = request.POST.get("date")
        check_in = request.POST.get("check_in")
        check_out = request.POST.get("check_out")
        if request.POST.get("is_present") == "on":
            is_present = True

        else:
            is_present = False
        if  request.POST.get("overtime_hours") == '':
            overtime_hours = "0.0"
        else:
            overtime_hours = request.POST.get("overtime_hours")
            
        leave_type = request.POST.get("leave_type")
        leave_reason = request.POST.get("leave_reason")
        notes = request.POST.get("note")
        attendance = AttendanceModel.objects.create(
            employee_id = employee,
            date = date,
            check_in = check_in,
            check_out = check_out,
            is_present = is_present,
            overtime_hours = overtime_hours,
            leave_type = leave_type,
            leave_reason = leave_reason,
            notes = notes
            )
        attendance.save()
        messages.success(request, "An attendance created successfully!")
        return redirect("/hr_attendances/show_attendances/")
    
@permission_required("hr_attendances.view_attendancemodel", login_url = "permission_required")    
def attendance_detail(request, attend_id):
    attendance = AttendanceModel.objects.get(id = attend_id)
    attendance.date = str(attendance.date)
    attendance.check_in = str(attendance.check_in)
    attendance.check_out = str(attendance.check_out)

    return render(request, "attendance_detail.html", {"attendance": attendance})

@permission_required("hr_attendances.update_attendancemodel", login_url = "permission_required")
def attendance_update(request, attend_id):
    attendance = AttendanceModel.objects.get(id = attend_id)

    if request.method == "GET":
        employee = EmployeeModel.objects.all()
        attendance.date = str(attendance.date)
        attendance.check_in = str(attendance.check_in)[0:-3]
        attendance.check_out = str(attendance.check_out)[0:-3]
        return render(request, "attendance_update.html", {"attendance": attendance, "all_employees": employee})

    if request.method == "POST":
        attendance.employee_id = request.POST.get("employee")
        attendance.date = request.POST.get("date")
        attendance.check_in = request.POST.get("check_in")
        attendance.check_out = request.POST.get("check_out")
        if request.POST.get("is_present") == "on":
            attendance.is_present = True
        else:
             attendance.is_present = False
        if request.POST.get("overtime_hours") == '':
            attendance.overtime_hours = 0.0
        else:
            attendance.overtime_hours = request.POST.get("overtime_hours")
        attendance.leave_type = request.POST.get("leave_type")
        attendance.leave_reason = request.POST.get("leave_reason")
        attendance.notes = request.POST.get("note")
        attendance.save()
        messages.success(request, "An attendance updated successfully!")
        return redirect("/hr_attendances/detail/" + str(attend_id) + "/")
    
@permission_required("hr_attendances.delete_attendancemodel", login_url = "permission_required")    
def attendance_delete(request, attend_id):
    attendance = AttendanceModel.objects.filter(id = attend_id)
    attendance.delete()
    messages.error(request, "An attendance deleted successfully!")
    return redirect("/hr_attendances/show_attendances/")

        
        
        