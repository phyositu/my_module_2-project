from django.contrib import admin
from .models import JobTagModel, ResumeTagModel, ContractTagModel, EmployeeTagModel

admin.site.register(JobTagModel)
admin.site.register(ResumeTagModel)
admin.site.register(ContractTagModel)
admin.site.register(EmployeeTagModel)
