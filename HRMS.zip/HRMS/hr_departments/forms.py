from django import forms
from django.forms import widgets
from .models import DepartmentModel
STATUS_CHOICES = (
    ('draft', 'Draft'),
    ('open', 'Open'),
    ('confirm', 'Confirm')
)
class DepartmentForm(forms.ModelForm):
    class Meta:
        model = DepartmentModel
        fields = "__all__"
        labels = {
            'name': 'Department Name',
            'sequence': 'Sequence',
            'meeting_date': 'Meeting Date',
            'total_employees': 'Total Employees',
            'note': 'Note',
            'status': 'Status',
            'is_active': 'Is Active?',
            'create_date': 'Create Date',
            'attachment': 'Attachment'
        }
        widgets = {
            'name': widgets.TextInput(attrs={'placeholder': 'enter department name', 'class': 'form-control'}),
            'sequence': widgets.NumberInput(attrs = {'placeholder': 'enter sequence', 'class': 'form-control'}),
            'meeting_date': widgets.DateInput(attrs = {'type': 'date', 'class': 'form-control'}),
            'total_employees': widgets.TextInput(attrs = {'placeholder': 'enter total employees', 'class': 'form-control'}),
            'note': widgets.TextInput(attrs = {'placeholder': "enter note", 'class': 'form-control'}),
            'status': widgets.Select(choices = STATUS_CHOICES, attrs = {'class': 'form-control'}),
            'is_active': widgets.CheckboxInput(),
            'create_date': widgets.DateTimeInput(attrs={'type': 'datetime-local', 'class': 'form-control'}),
            'attachment': widgets.ClearableFileInput()
        }
