from django.urls import path
from hr_departments import views

urlpatterns = [
    path('show_departments/', views.AllDepartments.as_view()),
    path('new_department/', views.addDepartment.as_view()),
    path('detail/<int:dep_id>/', views.Department.as_view()),
    path('update/<int:dep_id>/', views.updateDepartment.as_view()),
    path('delete/<int:dep_id>/', views.deleteDepartment.as_view()),
    path('order_by/', views.Order_by.as_view()),
    path('search_by/', views.Search_by.as_view()),
]