from django.contrib import admin
from .models import DepartmentModel
admin.site.register(DepartmentModel)
