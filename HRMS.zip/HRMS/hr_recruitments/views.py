from django.shortcuts import render, redirect
from django.views.generic import ListView, UpdateView, CreateView, DetailView, DeleteView
from django.urls import reverse_lazy
from .models import ResumeModel
from .forms import ResumeForm
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.views import View
from django.db.models import Q
from django.contrib import messages
class Order_by(View):
    pass
    
class Search_by(View):
    def get(self, request):
        search = request.GET.get('search')
        if search:
            resumes = ResumeModel.objects.filter(
                Q(name__icontains = search)|
                Q(sequence__icontains = search)|
                Q(appointment_date__icontains = search)|
                Q(note__icontains = search)|
                Q(status__icontains = search)|
                Q(create_date__icontains = search)
            )
        else:
            resumes = ResumeModel.objects.all()
        return render(request, 'resume_list.html', {'all_resumes': resumes})
    
class ResumeListView(LoginRequiredMixin, ListView):
    paginate_by = 2
    login_url = "login"
    
    model = ResumeModel
    context_object_name = 'all_resumes'
    template_name = "resume_list.html"

    def get_queryset(self):
        qs = super().get_queryset()
        order = self.request.GET.get("order")
        if order is not None:
            qs = ResumeModel.objects.all().order_by("-" + order)
        return qs

class ResumeCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    login_url = "permission_required"
    permission_required = 'hr_recruitments.add_resumemodel'
    model = ResumeModel
    context_object_name = 'form'
    template_name = 'resume_create.html'
    form_class = ResumeForm
    success_url = reverse_lazy('resume_list')
    def form_valid(self, form):
        messages.success(self.request, 'A Resume created successfully!')
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, 'something wrong. try again!')
        return super().form_invalid(form)

class ResumeUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    login_url = "permission_required"
    permission_required = 'hr_recruitments.update_resumemodel'
    model = ResumeModel
    context_object_name = 'form'
    form_class = ResumeForm
    template_name = 'resume_update.html'
    success_url = reverse_lazy('resume_list')

    def form_valid(self, form):
        messages.success(self.request, 'An resume updated successfully!')
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, 'something wrong. try again!')
        return super().form_invalid(form)

class ResumeDetailView(LoginRequiredMixin, PermissionRequiredMixin, DetailView):
    login_url = "permission_required"
    permission_required = 'hr_recruitments.view_resumemodel'
    model = ResumeModel
    context_object_name = 'resume'
    template_name = 'resume_detail.html'

class ResumeDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    login_url = "permission_required"
    permission_required = 'hr_recruitments.delete_resumemodel'
    model = ResumeModel
    context_object_name = 'resume'
    template_name = 'resume_delete.html'
    success_url = reverse_lazy('resume_list')

    def delete(self, request, *args, **kwargs):
        try:
            messages.error(self.request, 'An expense deleted successfully.')
            return super().delete(request, *args, **kwargs)

        except Exception as e:
            messages.error(self.request, f'Error deleting item: {str(e)}')
            return redirect(self.success_url)
