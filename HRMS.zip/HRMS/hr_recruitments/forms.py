from django import forms 
from django.forms import widgets
from .models import ResumeModel
STATUS_CHOICES = (
    ('draft', 'Draft'),
    ('confirm', 'Confirm'),
    ('open', 'Open')
)
class ResumeForm(forms.ModelForm):
    class Meta:
        model = ResumeModel
        fields = "__all__"
        labels = {
            'name': 'Enter Resume Name',
            'sequence': 'Enter Sequence',
            'appointment_date': 'Enter Appointment',
            'note': 'Enter Note',
            'status': 'Status',
            'is_active': 'Is Active?',
            'create_date': 'Enter Create Date',
            'attachment': 'Attachment',
            'employee': 'Employee',
            'tags': 'Tags'
        }
        widgets = {
            'name': widgets.TextInput(attrs={'placeholder': 'resume name', 'class': 'form-control'}),
            'sequence': widgets.NumberInput(attrs = {'placeholder': 'enter sequence', 'class': 'form-control'}),
            'appointment_date': widgets.DateInput(attrs = {'type': 'date', 'class': 'form-control'}),
            'note': widgets.TextInput(attrs = {'placeholder': 'note', 'class': 'form-control'}),
            'status': widgets.Select(choices = STATUS_CHOICES, attrs = {'class': 'form-control'}),
            'is_active': widgets.CheckboxInput(),
            'create_date': widgets.DateTimeInput(attrs = {'type': 'datetime-local', 'class': 'form-control'}),
            'attachment': widgets.ClearableFileInput(),
            'employee': widgets.Select(attrs = {'class': 'form-control'}),
            'tags': widgets.CheckboxSelectMultiple(),
        }