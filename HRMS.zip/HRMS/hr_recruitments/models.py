from django.db import models
from django.utils import timezone
from hr_employees.models import EmployeeModel
from hr_tags.models import ResumeTagModel

# from hr_tags.models import 
class ResumeModel(models.Model):
    def __str__(self):
        return self.name
    class Meta:
        permissions = (
            ('view_resumemodel', 'Can view resume model'),
        )
    name = models.CharField(max_length = 20, verbose_name = "Name")
    sequence = models.IntegerField(verbose_name = "Sequence")
    appointment_date = models.DateField(verbose_name = "Appointment_date", default = timezone.now)
    note = models.CharField(verbose_name = "note", max_length = 200, default = "good")
    status = models.CharField(verbose_name = "Status", max_length = 20, default = 'draft')
    is_active =models.BooleanField(verbose_name = "Is Active", default = None)
    create_date = models.DateTimeField(verbose_name = "Create Date", default = timezone.now)
    attachment = models.ImageField(verbose_name = "Attachment", default = None)
    employee = models.ForeignKey(EmployeeModel, on_delete = models.CASCADE, default = None)
    tags = models.ManyToManyField(ResumeTagModel)