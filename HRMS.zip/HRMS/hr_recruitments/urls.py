from django.urls import path
from hr_recruitments import views
urlpatterns = [
    path('show_resumes/', views.ResumeListView.as_view(), name="resume_list"),
    path('new_resume/', views.ResumeCreateView.as_view(), name="resume_create"),
    path('update/<int:pk>/', views.ResumeUpdateView.as_view(), name="resume_update"),
    path('detail/<int:pk>/', views.ResumeDetailView.as_view(), name="resume_detail"),
    path('delete/<int:pk>/', views.ResumeDeleteView.as_view(), name="resume_delete"),
    path('order_by/', views.Order_by.as_view()),
    path('search_by/', views.Search_by.as_view()),
]