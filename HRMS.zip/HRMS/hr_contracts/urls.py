from django.urls import path
from . import views
urlpatterns = [
    path('show_contracts/', views.all_contract),
    path('new_contract/', views.new_contract),
    path('update/<int:contract_id>/', views.update_contract),
    path('detail/<int:contract_id>/', views.detail_contract),
    path('delete/<int:contract_id>/', views.delete_contract),
    path('order_by/', views.order_by),
    path('search_by/', views.search_by),
]