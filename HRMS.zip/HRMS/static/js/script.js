// sidebar and header section start
const closeBtn = document.querySelector(".close-btn");
const header = document.querySelector(".header");
const sideBar = document.querySelector(".sideBar");
const openBtn = document.querySelector(".open-btn");
const sideBarItem = document.querySelectorAll(".sidebar ul li");

closeBtn.addEventListener("click", () => {
    header.style.position = "fixed";
    sideBar.style.display = "none";
    openBtn.style.display = "block";               
});
openBtn.addEventListener("click", () => {
    sideBar.style.display = "block";
    openBtn.style.display = "none";
    header.style.position = "absolute";
});

// sidebar and header section end
