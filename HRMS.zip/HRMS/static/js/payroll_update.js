const salaryInput = document.getElementById("id_salary");
const bonusesInput = document.getElementById("id_bonuses");
const deductionsInput = document.getElementById("id_deductions");
const netPayInput = document.getElementById("id_net_pay");

let cSalary = salaryInput.value;
let cBonuses = bonusesInput.value;
let cDeductions = deductionsInput.value;

const payRollCaculation = (salary, bonuses, deductions) => {
    const salaryFloat = parseFloat(salary);
    const bonusesFloat = parseFloat(bonuses);
    const deductionsFloat = parseFloat(deductions);
    if (isNaN(salaryFloat) || isNaN(bonusesFloat) || isNaN(deductionsFloat)) {
        return;
    }

    const result = salaryFloat - deductionsFloat + bonusesFloat;
    return result;
}

salaryInput.addEventListener("keyup", (e) => {
    cSalary = salaryInput.value;
    if (cSalary === "") {
        cSalary = 0;
    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    console.log(finalResult);
    netPayInput.value = finalResult;
});

deductionsInput.addEventListener("keyup", (e) => {
    cDeductions = deductionsInput.value;
    if (cDeductions === "") {
        cDeductions = 0;
    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    console.log(finalResult);
    netPayInput.value = finalResult;
    
});

bonusesInput.addEventListener("keyup", (e) => {
    cBonuses = bonusesInput.value;
    if (cBonuses === "") {
        cBonuses = 0;
    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    netPayInput.value = finalResult;
    
});