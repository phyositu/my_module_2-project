const salaryInput = document.getElementById("id_salary");
const bonusesInput = document.getElementById("id_bonuses");
const deductionsInput = document.getElementById("id_deductions");
const netPayInput = document.getElementById("id_net_pay");
const createBtn = document.querySelector("button[type=submit]");

let cSalary = 0;
let cBonuses = 0;
let cDeductions = 0;
netPayInput.value = 0;

window.addEventListener("load", () => {
    salaryInput.value = ""; 
    bonusesInput.value = 0; 
    deductionsInput.value = 0; 
});

const payRollCaculation = (salary, bonuses, deductions) => {
    const salaryFloat = parseFloat(salary);
    const bonusesFloat = parseFloat(bonuses);
    const deductionsFloat = parseFloat(deductions);
    if (isNaN(salaryFloat) || isNaN(bonusesFloat) || isNaN(deductionsFloat)) {
        return;
    }

    const result = salaryFloat - deductionsFloat + bonusesFloat;
    return result;
}

salaryInput.addEventListener("keyup", (e) => {
    cSalary = salaryInput.value;
    if (cSalary === "") {
        cSalary = 0;
    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    console.log(finalResult);
    netPayInput.value = finalResult;
});

deductionsInput.addEventListener("keyup", (e) => {
    cDeductions = deductionsInput.value;
    if (cDeductions === "") {
        cDeductions = 0;
    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    console.log(finalResult);
    netPayInput.value = finalResult;
    
});

bonusesInput.addEventListener("keyup", (e) => {
    cBonuses = bonusesInput.value;
    if (cBonuses === "") {
        cBonuses = 0;

    }
    const finalResult = payRollCaculation(cSalary, cBonuses, cDeductions);
    netPayInput.value = finalResult;
    
});

createBtn.addEventListener("click", () => {
    if (bonusesInput.value === "") {
        bonusesInput.value = 0;      
    }if (deductionsInput.value === "") {
        deductionsInput.value = 0;
        }
});